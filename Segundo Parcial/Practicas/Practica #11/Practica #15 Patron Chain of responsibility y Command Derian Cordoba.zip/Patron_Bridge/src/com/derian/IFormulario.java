package com.derian;

/**
 * @author derian-cordoba - 21/10/21
 * @project Patron_Bridge
 */
public interface IFormulario {
    void dibujaTexto(String texto);
    String administraZonaIndicada();
}
