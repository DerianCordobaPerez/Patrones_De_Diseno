package com.derian;

/**
 * @author derian-cordoba - 21/10/21
 * @project Patron_Adapter
 */
public interface Documento {

    void setContenido(String contenido);
    void dibuja();
    void imprime();

}
