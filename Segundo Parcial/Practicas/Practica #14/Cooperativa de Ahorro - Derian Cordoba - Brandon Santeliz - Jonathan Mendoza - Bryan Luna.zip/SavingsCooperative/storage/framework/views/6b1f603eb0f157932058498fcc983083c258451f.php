<?php if(auth()->user()->hasRole('Admin')): ?>
    <?php echo $__env->make('components.card', [
        'img' => 'roles/admin.jpg',
        'card_heading' => 'Panel de administracion',
        'card_text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, ullam?',
        'card_button' => 'Visitar'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(auth()->user()->hasRole('Cajero')): ?>
    <?php echo $__env->make('components.card', [
        'img' => 'roles/cashier.jpg',
        'card_heading' => 'Panel de Cajero',
        'card_text' => [
            'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, ullam?',
            'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, ullam?',
        ],
        'card_button' => 'Visitar'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/layouts/cards/card_role.blade.php ENDPATH**/ ?>