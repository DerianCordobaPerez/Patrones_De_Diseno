<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3">
            <?php echo $__env->make('layouts.cards.card_role', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-md-9">
            <div class="bg-dark rounded shadow p-4">
                <?php echo $__env->make('layouts.cards.card_actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/home.blade.php ENDPATH**/ ?>