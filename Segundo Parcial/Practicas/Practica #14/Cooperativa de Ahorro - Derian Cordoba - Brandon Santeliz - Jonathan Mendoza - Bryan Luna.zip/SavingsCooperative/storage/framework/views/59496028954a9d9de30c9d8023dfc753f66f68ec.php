<div class="row">
    <?php $__currentLoopData = auth()->user()->role->privileges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privilege): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 mb-2 d-flex align-items-stretch">
            <div class="card">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title fs-6"><?php echo e($privilege->name); ?></h5>
                    <a href="#" class="btn btn-primary mt-auto align-self-start fs-6"><?php echo e($privilege->name); ?></a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/cashiers/cards.blade.php ENDPATH**/ ?>