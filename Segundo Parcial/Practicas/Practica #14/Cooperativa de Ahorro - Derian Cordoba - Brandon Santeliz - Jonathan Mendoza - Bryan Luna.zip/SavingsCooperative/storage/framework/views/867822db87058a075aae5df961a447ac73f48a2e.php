<div class="card-sl">

    <?php if(isset($img)): ?>
        <div class="card-image">
            <img src="<?php echo e(asset("img/$img")); ?>" alt="img"/>
        </div>
    <?php endif; ?>

    <?php if(isset($card_heading)): ?>
        <div class="card-heading">
            <?php echo e($card_heading); ?>

        </div>
    <?php endif; ?>

    <?php if(isset($card_text)): ?>
        <?php if(is_array($card_text)): ?>
            <?php $__currentLoopData = $card_text; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-text">
                    <?php echo e($text); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="card-text">
                <?php echo e($card_text); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>

    <a class="card-button btn">
        <?php echo e($card_button); ?>

    </a>
</div>
<?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/components/card.blade.php ENDPATH**/ ?>