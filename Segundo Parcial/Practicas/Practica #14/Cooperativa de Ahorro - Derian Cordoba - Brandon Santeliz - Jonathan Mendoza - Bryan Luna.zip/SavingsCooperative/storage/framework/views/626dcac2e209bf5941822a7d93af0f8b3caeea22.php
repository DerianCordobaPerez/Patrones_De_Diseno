<?php if(auth()->user()->hasRole('Admin')): ?>
    <?php echo $__env->make('admins.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(auth()->user()->hasRole('Cajero')): ?>
    <?php echo $__env->make('cashiers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/layouts/cards/card_actions.blade.php ENDPATH**/ ?>