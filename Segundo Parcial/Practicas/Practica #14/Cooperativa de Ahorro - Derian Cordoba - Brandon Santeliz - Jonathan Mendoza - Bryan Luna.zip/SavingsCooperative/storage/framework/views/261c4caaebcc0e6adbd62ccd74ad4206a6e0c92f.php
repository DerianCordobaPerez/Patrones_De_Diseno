<?php $__env->startSection('content'); ?>

    <div class="row my-2">
        <div class="col-md-12">
            <h2 class="text-center text-white my-2"><u><?php echo e(!isset($userRole) ? 'Creacion' : 'Edicion'); ?> de empleado</u></h2>

            <div class="card bg-dark rounded shadow text-white col-8 mx-auto p-4">

                <form method="POST" action="<?php echo e(!isset($userRole) ? route('userRoles.store') : route('userRoles.update', $userRole->id)); ?>">

                    <?php echo csrf_field(); ?>
                    <?php if(isset($userRole)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Nombre</label>
                        <input type="text" class="form-control col-md-6" name="name" value="<?php echo e($userRole->employee->name ?? ''); ?>" required>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Identificacion</label>
                        <input type="text" class="form-control col-md-6" name="identification" value="<?php echo e($userRole->employee->identification ?? ''); ?>" required>
                    </div>

                    <div class="row">
                        <div class="col">
                            <label>Genero</label>
                        </div>
                        <div class="col">
                            <label>
                                Femenino
                                <input type="radio" name="sex" value="f"
                                    <?php if(isset($userRole)): ?>
                                        <?php if($userRole->employee->sex === 'f'): ?> checked <?php endif; ?>
                                    <?php endif; ?>
                                >
                            </label>

                            <label>
                                Masculino
                                <input type="radio" name="sex" value="m"
                                    <?php if(isset($userRole)): ?>
                                       <?php if($userRole->employee->sex === 'm'): ?> checked <?php endif; ?>
                                    <?php endif; ?>
                                >
                            </label>&nbsp;&nbsp;
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <label>Estado Civil</label>
                        </div>
                        <div class="col">
                            <label>
                                Soltero
                                <input type="radio" name="marital_status" value="single"
                                    <?php if(isset($userRole)): ?>
                                       <?php if($userRole->employee->marital_status === 'single'): ?> checked <?php endif; ?>
                                    <?php endif; ?>
                                >
                            </label>

                            <label>
                                Casado
                                <input type="radio" name="marital_status" value="married"
                                    <?php if(isset($userRole)): ?>
                                       <?php if($userRole->employee->marital_status === 'married'): ?> checked <?php endif; ?>
                                    <?php endif; ?>
                                >
                            </label>&nbsp;&nbsp;

                            <label>
                                Relacion Libre
                                <input type="radio" name="marital_status" value="free relationship"
                                    <?php if(isset($userRole)): ?>
                                       <?php if($userRole->employee->marital_status === 'free relationship'): ?> checked <?php endif; ?>
                                    <?php endif; ?>
                                >
                            </label>&nbsp;&nbsp;
                        </div>
                    </div>

                    <!--Email-->
                    <div class="form-input input-group my-2">
                        <span class="input-group-text">Mail Personal</span>
                        <input type="email" class="form-control col-md-6" name="personal_mail" value="<?php echo e($userRole->employee->personal_mail ?? ''); ?>" required>
                    </div>
                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Mail Interno</label>
                        <input type="email" class="form-control col-md-6" name="internal_mail" value="<?php echo e($userRole->employee->internal_mail ?? ''); ?>" required>
                    </div>

                    <!--Clave-->
                    <div class="form-input input-group my-2">
                        <span class="input-group-text">Clave</span>
                        <input type="password" class="form-control col-md-6" name="password" required>
                    </div>

                    <!--Profesion-->
                    <div class="form-input input-group my-2">
                        <span class="input-group-text">Profesion</span>
                        <input type="text" class="form-control col-md-6" name="profession" value="<?php echo e($userRole->employee->profession ?? ''); ?>" required>
                    </div>

                    <!--Fecha-->
                    <div class="row">
                        <div class="form-input input-group my-2 col">
                            <span class="input-group-text">Fecha de Nacimiento</span>
                            <input type="date" class="form-control col-md-6" name="date_of_birth" value="<?php echo e($userRole->employee->date_of_birth ?? ''); ?>" required>
                        </div>

                        <div class="form-input input-group my-2 col">
                            <span class="input-group-text">Nacionalidad</span>
                            <select name="nationality">
                                <option>Nicaraguense</option>
                                <option>Aleman</option>
                                <option>Estado Unidense</option>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-input input-group my-2 col">
                            <span class="input-group-text">Fecha de Ingreso</span>
                            <input type="date" class="form-control col-md-6" name="date_of_admission" value="<?php echo e($userRole->employee->date_of_admission ?? ''); ?>" required>
                        </div>

                        <div class="form-input input-group my-2 col">
                            <span class="input-group-text">Fecha de Salida</span>
                            <input type="date" class="form-control col-md-6" name="departure_date" value="<?php echo e($userRole->employee->departure_date ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="form-input input-group my-2">
                        <span class="input-group-text">Rol</span>
                        <select name="role_id">
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->role_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="row">
                        <div class="form-input input-group mb-2 col">
                            <span class="input-group-text">Fecha Inicio Rol</span>
                            <input type="date" class="form-control col-md-6" name="start_date" value="<?php echo e($userRole->start_date ?? ''); ?>" required>
                        </div>

                        <div class="form-input input-group mb-2 col">
                            <span class="input-group-text">Fecha Salida Rol</span>
                            <input type="date" class="form-control col-md-6" name="final_date" value="<?php echo e($userRole->final_date ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="d-grid gap-2 col-6 mx-auto">
                            <button type="submit" name="send" class="btn btn-success">Guardar</button>
                        </div>

                        <div class="d-grid gap-2 col-6 mx-auto">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-warning mx-2 ">Cancelar</a>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/users/createEdit.blade.php ENDPATH**/ ?>