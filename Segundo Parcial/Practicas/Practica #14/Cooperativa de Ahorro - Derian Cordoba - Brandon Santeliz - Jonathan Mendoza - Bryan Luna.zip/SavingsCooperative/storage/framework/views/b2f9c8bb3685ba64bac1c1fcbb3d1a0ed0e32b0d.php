<?php if(auth()->user()->hasRole('Admin')): ?>
    <?php echo $__env->make('components.card', [
        'img' => 'admins.jpg',
        'card_heading' => 'Panel de administracion',
        'card_text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, ullam?',
        'card_button' => 'Visitar'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(auth()->user()->hasRole('Cajero')): ?>
    <?php echo $__env->make('components.card', [
        'img' => 'cajera.jpg',
        'card_heading' => 'Panel de Cajero',
        'card_text' => [
            'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, ullam?',
            'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, ullam?',
        ],
        'card_button' => 'Visitar'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/layouts/card_role.blade.php ENDPATH**/ ?>
