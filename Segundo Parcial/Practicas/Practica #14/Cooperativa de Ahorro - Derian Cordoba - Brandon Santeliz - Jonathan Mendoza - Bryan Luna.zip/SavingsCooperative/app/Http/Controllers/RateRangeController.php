<?php

namespace App\Http\Controllers;

use App\Models\RateRange;
use Illuminate\Http\Request;

class RateRangeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\RateRange  $rateRange
     * @return \Illuminate\Http\Response
     */
    public function show(RateRange $rateRange)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\RateRange  $rateRange
     * @return \Illuminate\Http\Response
     */
    public function edit(RateRange $rateRange)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\RateRange  $rateRange
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RateRange $rateRange)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\RateRange  $rateRange
     * @return \Illuminate\Http\Response
     */
    public function destroy(RateRange $rateRange)
    {
        //
    }
}
