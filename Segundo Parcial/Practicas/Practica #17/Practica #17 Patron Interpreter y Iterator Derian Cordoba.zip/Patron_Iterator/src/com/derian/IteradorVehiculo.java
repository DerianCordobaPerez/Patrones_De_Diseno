package com.derian;

/**
 * @author derian-cordoba - 22/11/21
 * @project Patron_Iterator
 */
public class IteradorVehiculo extends Iterador<Vehiculo> {
}
