package com.derian;

/**
 * @author derian-cordoba - 21/10/21
 * @project Patron_Facade
 */
public interface GestionDocumento {
    String documento(int indice);
}
