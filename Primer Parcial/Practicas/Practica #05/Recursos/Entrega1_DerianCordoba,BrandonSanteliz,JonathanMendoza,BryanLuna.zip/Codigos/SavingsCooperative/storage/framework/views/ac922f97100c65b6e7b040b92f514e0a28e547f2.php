<?php $__env->startSection('content'); ?>
    <div class="row my-2">
        <div class="col-md-12">
            <h2 class="text-center text-white my-2"><u><?php echo e(!isset($role) ? 'Creacion' : 'Edicion'); ?> de roles</u></h2>

            <div class="card bg-dark rounded shadow text-white col-8 mx-auto p-4">
                <form method="POST" action="<?php echo e(!isset($role) ? route('roles.store') : route('roles.edit', $role->role_code)); ?>">
                    <?php echo csrf_field(); ?>

                    <label class="my-2">
                        Nombre del rol:
                        <input type="text" name="role_name" class="mx-2 rounded" value="<?php echo e(isset($role) ? $role->role_name : ''); ?>">
                    </label>

                    <label class="mx-2">
                        Seleccionar todos los privilegios
                        <input type="checkbox" onclick="toggle(this)">
                    </label>

                    <div class="row text-justify">
                        <?php $__currentLoopData = $privileges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privilege): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <?php $__currentLoopData = $privilege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row my-4 form-check form-switch">
                                        <label>
                                            <?php echo e($item->name); ?>

                                            <input type="checkbox" name="privileges[]" value="<?php echo e($item->id); ?>" class="form-check-input">
                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="my-2 d-grid gap-2 col-6 mx-auto">
                        <button class="btn btn-primary" type="submit">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        const toggle = source => {
            const checkboxes = document.getElementsByName('privileges[]')
            for(let i = 0; i < checkboxes.length; ++i)
                checkboxes[i].checked = source.checked
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/derian-cordoba/Documentos/Universidad/CLASES/QUINTO AÑO/SEGUNDO SEMESTRE/Patrones de  Diseño/Primer Parcial/Practicas/Practica #05/Recursos/Codigos/SavingsCooperative/resources/views/roles/createEdit.blade.php ENDPATH**/ ?>