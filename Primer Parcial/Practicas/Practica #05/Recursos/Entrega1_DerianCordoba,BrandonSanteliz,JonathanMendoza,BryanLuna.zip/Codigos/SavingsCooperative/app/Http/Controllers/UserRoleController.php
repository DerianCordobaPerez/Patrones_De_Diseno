<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Role;
use App\Models\UserRole;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * Class UserRoleController
 * @package App\Http\Controllers
 */
class UserRoleController extends Controller
{

    /**
     * Show list userRoles
     *
     * @return View
     */
    public function index(): View {
        return view('users.index')
            ->with('userRoles', UserRole::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return View
     */
    public function create(): View
    {
        return view('users.createEdit')
            ->with('userRole')
            ->with('roles', (new Role())->all());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return RedirectResponse
     */
    public function store(Request $request): RedirectResponse
    {
        $employee = (new Employee())->create($request->except([
            'password', 'role', 'start_date', 'final_date'
        ]));

        (new UserRole())->create([
            'employee_code' => $employee->employee_code,
            'role_code' => $request->role,
            'password' => $request->password,
            'start_date' => $request->start_date,
            'final_date' => $request->final_date
        ]);

        return redirect()->route('userRoles.index')
            ->with('success', 'Empleado creado correctamente')
            ->with('userRoles', UserRole::all());
    }

    /**
     * Display the specified resource.
     *
     * @param UserRole $userRole
     * @return View
     */
    public function show(UserRole $userRole): View
    {
        return view('users.show')
            ->with('userRole', $userRole);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param UserRole $userRole
     * @return View
     */
    public function edit(UserRole $userRole): View
    {
        return view('users.createEdit')
            ->with('roles', (new Role())->select()->whereNotIn('role_name', [$userRole->role->role_name])->get())
            ->with('userRole', $userRole);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param UserRole $userRole
     * @return RedirectResponse
     */
    public function update(Request $request, UserRole $userRole): RedirectResponse
    {
        return redirect()->route('');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param UserRole $userRole
     * @return RedirectResponse
     */
    public function destroy(UserRole $userRole): RedirectResponse
    {
        $userRole->delete();
        return redirect()->route('userRoles.index')
            ->with('success', 'Empleado eliminado correctamente')
            ->with('userRoles', UserRole::all());
    }
}
