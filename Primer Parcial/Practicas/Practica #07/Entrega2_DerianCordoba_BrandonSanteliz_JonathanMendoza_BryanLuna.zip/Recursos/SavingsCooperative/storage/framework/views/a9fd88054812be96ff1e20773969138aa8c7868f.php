<?php $__env->startSection('content'); ?>

    <?php if($partner->requests->count() > 0): ?>
        <div class="container">

            <h2 class="text-white text-center"><b>Nombre socio:</b> <u><?php echo e($partner->user_name); ?></u><br></h2>

            <table class="table table-dark table-striped shadow p-3 mb-5 bg-body rounded">
                <thead>
                <tr>
                    <th scope="col"><h3>Informacion</h3> </th>
                    <th scope="col"><h3>Acciones</h3> </th>
                </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $partner->requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <b>Fecha de admision:</b> <?php echo e($request->date_of_admission); ?><br>
                                <b>Direccion:</b> <?php echo e($request->direction); ?><br>
                                <b>Estado:</b> <?php echo e($request->status); ?><br>
                                <b>Fecha:</b> <?php echo e($request->date); ?><br>
                            </td>

                            <td>
                                <div class="btn-group mx-auto" role="group" aria-label="derian">

                                    <a href="<?php echo e(route('requests.edit', $request->id)); ?>" class="btn btn-warning text-white mx-2">
                                        <i class="fas fa-pencil-alt"></i>
                                        Editar
                                    </a>

                                    <form action="<?php echo e(route('requests.destroy', $request->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" name="send">
                                            <i class="fas fa-trash-alt"></i>
                                            Eliminar
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="my-2 d-grid gap-2 col-6 mx-auto">
                <a href="<?php echo e(route('home')); ?>" class="btn btn-success text-white">Volver al inicio</a>
            </div>

        </div>
    <?php else: ?>
        <div class="bg-dark p-4 rounded shadow p-3 mb-5">
            <h1 class="text-white text-center my-2">No se han agregado socios</h1>

            <div class="row mx-auto">
                <div class="my-2 d-grid gap-2 col-6 mx-auto">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-success text-white">Volver al inicio</a>
                </div>

                <div class="my-2 d-grid gap-2 col-6 mx-auto">
                    <a href="<?php echo e(route('requests.create')); ?>" class="btn btn-success text-white">Crear un socio</a>
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/partners/show.blade.php ENDPATH**/ ?>