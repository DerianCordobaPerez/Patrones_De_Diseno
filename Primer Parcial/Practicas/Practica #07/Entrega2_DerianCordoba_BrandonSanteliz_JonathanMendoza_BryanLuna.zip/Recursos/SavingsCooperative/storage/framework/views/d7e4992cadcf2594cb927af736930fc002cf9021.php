<?php $__env->startSection('content'); ?>

    <div class="row my-2">
        <div class="col-md-12">
            <h2 class="text-center text-white my-2"><u><?php echo e(!isset($request) ? 'Creacion' : 'Edicion'); ?> de solicitud</u></h2>

            <div class="card bg-dark rounded shadow text-white col-8 mx-auto p-4">
                <form method="POST" action="<?php echo e(!isset($request) ? route('requests.store') : route('requests.update', $request->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($request)): ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="partner_id" value="<?php echo e($request->partner->id); ?>">

                    <?php else: ?>
                        <div class="form-input input-group my-2">
                            <label class="input-group-text">Socio</label>
                            <select name="partner_id">
                                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($partner->id); ?>"><?php echo e($partner->user_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Usuario</label>
                        <select name="user_role_id">
                            <?php $__currentLoopData = $user_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user_role->id); ?>"><?php echo e($user_role->employee->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Fecha de admision</label>
                        <input type="date" class="form-control col-md-6" name="date_of_admission" value="<?php echo e($request->date_of_admission ?? ''); ?>" required>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Modulo</label>
                        <select name="module">
                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($module->id); ?>"><?php echo e($module->id); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Producto</label>
                        <select name="product">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Sucursal</label>
                        <select name="branch_office">
                            <?php $__currentLoopData = $branch_offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch_office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch_office->id); ?>"><?php echo e($branch_office->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Oficina</label>
                        <select name="office">
                            <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($office->id); ?>"><?php echo e($office->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Fecha</label>
                        <input type="date" class="form-control col-md-6" name="date" value="<?php echo e($request->date ?? ''); ?>" required>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Direccion</label>
                        <input type="text" class="form-control col-md-6" name="direction" value="<?php echo e($request->direction ?? ''); ?>" required>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Observacion</label>
                        <input type="text" class="form-control col-md-6" name="observation" value="<?php echo e($request->observation ?? ''); ?>" required>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Estado</label>
                        <input type="text" class="form-control col-md-6" name="status" value="<?php echo e($request->status ?? ''); ?>" required>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Numero de cuenta</label>
                        <select name="number_account">
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($account->id); ?>"><?php echo e($account->id); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Monto</label>
                        <input type="number" class="form-control col-md-6" name="amount" value="<?php echo e($request->amount ?? ''); ?>" required>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Efectivo</label>
                        <input type="number" class="form-control col-md-6" name="cash" value="<?php echo e($request->cash ?? ''); ?>" required>
                    </div>

                    <div class="form-input input-group my-2">
                        <label class="input-group-text">Cheque</label>
                        <input type="text" class="form-control col-md-6" name="check" value="<?php echo e($request->check ?? ''); ?>" required>
                    </div>

                    <div class="my-2 d-grid gap-2 col-6 mx-auto">
                        <button class="btn btn-primary" type="submit">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/requests/createEdit.blade.php ENDPATH**/ ?>