<?php $__env->startSection('content'); ?>
    <div class="mt-4 mx-auto alert alert-danger text-center">
        <h2 class="display-2">404</h2>
        <p class="display-5">Oops! La pagina no ha sido encontrada.</p>
        <a class="display-6" href="<?php echo e(route('home')); ?>">Volver al inicio</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/derian-cordoba/PhpstormProjects/SavingsCooperative/resources/views/errors/404.blade.php ENDPATH**/ ?>