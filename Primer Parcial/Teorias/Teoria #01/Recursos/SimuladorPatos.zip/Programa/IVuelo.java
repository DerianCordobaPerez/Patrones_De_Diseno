interface IVuelo
{
	public String volar();	
}