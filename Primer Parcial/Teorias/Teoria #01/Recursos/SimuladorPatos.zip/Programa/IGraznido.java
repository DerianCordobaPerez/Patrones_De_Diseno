interface IGraznido
{
	public String graznar();	
}