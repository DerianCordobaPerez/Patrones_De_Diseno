public class NoVolar implements IVuelo 
{
	public String volar() 
	{
		return "* No Vuelo *";
	}
}
