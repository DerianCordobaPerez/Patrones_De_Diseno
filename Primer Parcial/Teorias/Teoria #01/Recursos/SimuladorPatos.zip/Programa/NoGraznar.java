public class NoGraznar implements IGraznido 
{
	public String graznar() 
	{
		return "* No Grazno *";
	}
}
