public class VolarAlto implements IVuelo 
{
	public String volar() 
	{
		return "* Vuelo Alto *";
	}
}
