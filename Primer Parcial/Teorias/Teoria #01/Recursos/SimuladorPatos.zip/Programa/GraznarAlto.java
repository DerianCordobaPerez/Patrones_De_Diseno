public class GraznarAlto implements IGraznido 
{
	public String graznar() 
	{
		return "* Grazno Alto *";
	}
}
