package MarkerInt;

public class Moto implements MotorInt {

    private int cilindrada;

    public Moto(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }
    
    @Override
    public String toString()
    {
        return "Moto: " + this.cilindrada;
    }
    
}
