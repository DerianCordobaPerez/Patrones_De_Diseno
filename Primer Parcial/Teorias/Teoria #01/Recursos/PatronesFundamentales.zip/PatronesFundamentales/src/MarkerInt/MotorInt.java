package MarkerInt;

//interfaz vacía (bandera)
public interface MotorInt {
    
}
