package MarkerInt;

public class Bicicleta {

    private String tipo;

    public Bicicleta(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    @Override
    public String toString()
    {
        return "Bicicleta: " + this.tipo;
    }
}
