package MarkerInt;

import java.util.ArrayList;

public class Cliente {

    public static void main(String[] args) {
        //Lista de vehículos
        ArrayList vehiculos = new ArrayList();
        //Lista de vehículos con motor
        ArrayList<MotorInt> vehiculosConMotor = new ArrayList<MotorInt>();

        MotorInt c1 = new Coche(5);
        MotorInt c2 = new Coche(2);
        MotorInt m1 = new Moto(250);
        MotorInt m2 = new Moto(650);
        Bicicleta b1 = new Bicicleta("montaña");
        Bicicleta b2 = new Bicicleta("carretera");

        //Añadimos los vehículos a la lista
        vehiculos.add(c1);
        vehiculos.add(c2);
        vehiculos.add(m1);
        vehiculos.add(m2);
        vehiculos.add(b1);
        vehiculos.add(b2);

        //Seleccionamos solo los que tienen motor
        for (int i = 0; i < vehiculos.size(); i++) {
            if (vehiculos.get(i) instanceof MotorInt) {
                vehiculosConMotor.add((MotorInt) vehiculos.get(i));
            }
        }

        System.out.println(vehiculosConMotor.toString());

    }
}
