package DelegationInt;

public interface Descripcion {

    public String descripcion();
}
