package IntAbsClass;

public interface IntTrabajo {

    String getEmpresa();

    void setEmpresa(String nueva);

    double getSueldo();

    void setSueldo(double euros);

    double pagarSueldo(double horas);
}
